This function demonstrate the use of Fetch to return the BusinessUnitName for the current user. 
_Thanks to [Peter000000](http://www.codeplex.com/site/users/view/Peter000000)_

{code:javascript}
function GetBusinessUnitName() {
    var lGetBusinessUnitName;

    var fetchXml = "<fetch mapping='logical'>" +
                   "<entity name='systemuser'>" +
                   "<attribute name='businessunitid' />" +
                   "<filter type='and'>" +
                   "<condition attribute='systemuserid' operator='eq-userid' />" +
                   "</filter>" +
                   "</entity>" +
                   "</fetch>";

            XrmSvcToolkit.fetch({
                fetchXml: fetchXml,
                async: false,
                successCallback: function (result) {
                    lGetBusinessUnitName =  result.entities[0](0).businessunitid.Name;
                },
                errorCallback: function (error) {
                    throw error;
                }
            });

    return lGetBusinessUnitName;
}
{code:javascript}