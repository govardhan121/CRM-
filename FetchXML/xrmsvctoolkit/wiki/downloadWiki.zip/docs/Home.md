## Description
XrmSvcToolkit is a small JavaScript library that helps you access Microsoft Dynamics CRM 2011 web service interfaces (SOAP and REST). 
## Roadmap
At long last we have a shared vision where the project is heading, at least for the next couple releases. Read it all in our [Roadmap](Roadmap)
## Manifesto
: _"[Damn kids. They're all alike.](http://www.phrack.org/issues.html?issue=7&id=3&mode=txt)"_
We often asked why this project even exists, and wouldn't everyone be better off if we folded with [XrmServiceToolkit](http://xrmservicetoolkit.codeplex.com). Perhaps. However, we believe that toolkit has to be:
* fast & small
* dedicated to the cause & focused
* with minimal external dependencies
* faster & smaller
XrmServiceToolkit is a comprehensive library that borrowed many ideas from [CRM Web Service Toolkit for CRM 4.0](http://crmtoolkit.codeplex.com/), including no longer required concepts like BusinessEntity. Considering the objectives above, mean and lean library will serve the purpose better so here you have it. But in the end, of course, it's down to individual preferences. 
## Documentation
It is now where it should be -- under [Documentation](Documentation)
## Project Sponsor
XrmSvcToolkit is an open source project contributed by KingswaySoft, a software product and service company specializing in Microsoft Dynamics CRM and business intelligence development. 
![KingswaySoft](Home_KingswaySoft-Logo.png|http://www.kingswaysoft.com)
XrmSvcToolkit  is developed by Daniel Cai, who was the developer of [CRM Web Service Toolkit for CRM 4.0](http://crmtoolkit.codeplex.com). XrmSvcToolkit is a complete rewrite which doesn't have the same interfaces of CRM Service Toolkit. 