## Supported Functions
* createRecord (REST)
* updateRecord (REST)
* deleteRecord (REST)
* retrieve (REST)
* retrieveMultiple (REST)
* associate (REST)
* disassociate (REST)
* setState (SOAP)
* fetch (SOAP)
* execute (SOAP)

## Quick Sample
{code:javascript}
XrmSvcToolkit.createRecord({
    entityName: "Contact",
    entity: {FirstName: "Joe", LastName: "Foo" },
    async: false,
    successCallback: function (result) {
        var contactId = result.ContactId;
        // do the rest stuff
    },
    errorCallback: function (error) {
        alert("There was an error when creating the contact record");
    }
});
{code:javascript}

## Samples
* [Use Fetch to return the business unit name for the current user](http://xrmsvctoolkit.codeplex.com/wikipage?title=SampleRetrieveBUName&referringTitle=Documentation)