﻿var requestMain = ""
requestMain += "    <Execute xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">";
requestMain += "      <request i:type=\"b:RetrieveVersionRequest\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\" xmlns:b=\"http://schemas.microsoft.com/crm/2011/Contracts\">";
requestMain += "        <a:Parameters xmlns:c=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\" />";
requestMain += "        <a:RequestId i:nil=\"true\" />";
requestMain += "        <a:RequestName>RetrieveVersion</a:RequestName>";
requestMain += "      </request>";
requestMain += "    </Execute>";

