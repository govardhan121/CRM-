## CRM 2013 and XrmServiceToolkit

To support CRM 2013, there are lots of works to be done for the toolkit

**Download**

Please download the latest version

**Tested CRM 2013 server**
* PC
	* CRM 2013 on-premise for IE10, latest chrome, latest firefox
	* CRM 2013 online for IE10, latest chrome, latest firefox
* Tablet - iPad 2, iOS 7.0.2
	* CRM 2013 online for latest chrome, latest safari
* Tablet Client - Remember the limitations of CRM events for tablet apps.
	* iOS client - iPad 2, iOS 7.0.2
	* Windows App - Windows 8, Windows RT

Tablet client OnLoad : You may have a +"alert" is not defined error+ when the app is initially loaded, but the problem should be gone once the app / page is fully loaded. This may be caused by "In Microsoft Dynamics CRM for tablets any use of the window.alert method will be overridden to use Xrm.Utility.alertDialog without a callback"

Please try it in your CRM 2013 test environment and report issues, bugs

_If reporting bugs, please start with CRM2013 or CRM2011, so it will be easier for us to target the CRM environment_

**Dependency**
The toolkit will still require JSON2, jQuery to be used to support some conversion and extension methods. 

**NOTE:** The attached jQuery in the solution has some changes applied to make sure the toolkit will work on Form 
 
{{ 
// Expose jQuery to the global object
window.jQuery = jQuery;
}}
All the $ usage has been removed from the toolkit. Instead, jQuery is used to avoid conflict

**Development Tools and Environment**
* Visual Studio 2012 + Update 3
* IE10, latest Chrome, latest Firefox, latest Safari
* CRM 2013 SDK beta
* CRM 2013 on-premise RTM, CRM 2013 online for PC and Tablet - iPad
* Windows Server 2012
* SQL Server 2012
* jQuery v1.7.2 , QUnit v1.12.0
All these are used in a windows 8 Hyper-V server

**Release Note**
* New Behavior - XrmServiceTookit.Soap.Fetch parameters change to work with asynchronous callback compared to 1.4.2 beta: XrmServiceToolkit.Soap.Fetch(fetchXml, fetchAll, callback)
* New Behavior - XrmServiceTookit.Common.AddNotification is working with CRM 2013 using the out-of-box functionality. Still support CRM 2011
* New Fix - XrmServiceToolkit.Comon.GetObjectCodeType is now using metadata retrieval as a supported method
* New Fix - The included jQuery has a line changed at the bottom <window.jQuery = jQuery;> $ is removed to work with CRM 2013 form

**To be continued**

* New CRM 2013 methods will be added if needed
* More functions and modifications will be added to support tablet layout, outlook client, etc
* Better Performance tuning and changes along the way to support CRM 2013 for cross browser, cross platform (web, tablet, mobile, etc)
* Add-ons which developed using XrmServiceTookit will be added to the project in the future. In the format of source code and CRM solution

Happy Coding,
Jaimie Ji