**CRM 2011 Rollup 12 is coming**
 
New year has always been very busy for lots of things. There is no doubt for us, MSCRM consultants...

Last week, i got an email from Microsoft CRM team to notice me that my personal CRM online subscription will be updated to Rollup 12 which was exciting news because i finally have an environment to test and development XrmServiceToolkit and make an effort to support cross browser. 

The upgrade obviously is a big deal for everyone. There are some immediate problems which i have seen for the toolkit after my instance was running RU12. 

Version 1.4.0 is far from perfection at its current stage to support cross browser cause there will be so many things to do and so much testing shall be done. 

If you have used the toolkit previously for your project, thanks very much for your support. For version 1.4.0, download and try it out using a +testing+ environment and let me know issues and bugs. 

Happy Coding,
Jaimie